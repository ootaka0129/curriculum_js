package test.exception;

public class BankException {

    public static void main(String[] args) {
        // TODO 自動生成されたメソッド・スタブ

    }

}
